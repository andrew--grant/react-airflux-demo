import React from 'react';
import QuantitySelectorStore from '../../airflux/stores/QuantitySelectorStore.js';

export default class DynamicInputPanel extends React.Component {


    onChange(status) {
        this.setState({
            currentStatus: status
        });
    }

    store() {
        return this.store;
    }

    componentDidMount() {
        var store = new QuantitySelectorStore();
        store.listen(this.onChange);
    }

    componentWillUnmount() {
        this.unsubscribe();
    }

    render() {
        var inputs = [];
        for (var i = 1; i <= this.props.numberOfInputs; i++) {
            inputs.push(<div key={i}><input type="text" name="input"/></div>)
        }
        return (
            <div id="dynamic-input-panel">
                <h2>DynamicInputPanel</h2>
                {inputs}
            </div>
        );
    }
}

DynamicInputPanel.propTypes = {
    numberOfInputs: React.PropTypes.number
};

DynamicInputPanel.defaultProps = {
    numberOfInputs: 1
};