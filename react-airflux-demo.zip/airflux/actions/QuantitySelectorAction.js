import Airflux from 'airflux';

export default class QuantitySelectorAction{

    constructor() {
        this.action = new Airflux.Action();
        this.action.listen(() => {
            console.log("yayy!!");
        });
    }

    getAction() {
        return this.action().asFunction;
    }
}

// todo: export only the var, not the above class
export var quantitySelectorAction = new QuantitySelectorAction();
