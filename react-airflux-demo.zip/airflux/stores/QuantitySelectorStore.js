import Airflux from 'airflux';
import {quantitySelectorAction,QuantitySelectorAction} from './../actions/QuantitySelectorAction.js';

export default class QuantitySelectorStore extends Airflux.Store {

    constructor() {
        super();
        console.log(quantitySelectorAction);
        //var quantitySelectedAction = quantitySelectorAction//new QuantitySelectorAction().getAction();
        this.listen(quantitySelectorAction, this.manageInputs);
    }

    manageInputs() {
        console.log("manageInputs called ");
    }
}
// todo: export only the var, not the above class
export var quantitySelectorStore = new QuantitySelectorStore();